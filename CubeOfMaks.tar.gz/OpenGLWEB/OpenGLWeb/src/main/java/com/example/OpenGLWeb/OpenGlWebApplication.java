package com.example.OpenGLWeb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OpenGlWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(OpenGlWebApplication.class, args);
	}

}
